<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Model  // Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['email'];
    
    public function address(){
      return $this-> hasMany('App/Models/Addresse');
    }

    public function session(){
      return $this->hasOne('App/Models/Session');
    }

    public function detail(){
      return $this->hasMany('App/Models/Detail');
    }

}
?>
