<?php
  namespace  App\Http\Controllers;
  use Illuminate\Routing\Controller;
  use App\Models\User;
  use App\Http\Controllers\PagesController;
  use Illuminate\Support\Facades\DB;
  use Illuminate\Support\Facades\Route;
  use Illuminate\Support\Facades\Session;

  class CartController extends Controller {
    public function index(){
      return view('cart');
    }

    private function email_id($email){
      $user=User::where('email', $email)->first();
      return $user['id'];
    }

    public function get_cart($email){
      $user_id=$this->email_id($email);
      $products=DB::table('discounts')
                ->join('products', 'discounts.id','=', 'products.discount_id')
                ->join('carts', 'carts.product_id','=', 'products.id')
                ->join('sessions', 'sessions.id','=', 'carts.session_id')
                ->select('discounts.percentage', 'discounts.active', 'products.sku', 'products.name', 'products.price', 'products.pic', 'carts.quantity' , 'sessions.total')
                ->where('sessions.user_id', $user_id)
                ->get();
      return response()->json($products);
    }

    public function delete_item($email,$sku){
      $user_id=$this->email_id($email);
      $active=DB::table('discounts')
                ->join('products', 'discounts.id','=', 'products.discount_id')
                ->select('discounts.active')
                ->where('products.sku',$sku)
                ->get();

      if($active[0]->active===0){
        DB::table('sessions')
          ->where('sessions.user_id', $user_id)
          ->update(['total'=>DB::raw('total-'.
          (DB::table('products')
            ->select('price')
            ->where('sku',$sku)->get()->value('price')). '*' .(DB::table('products')
                                            ->join('carts','carts.product_id','=','products.id')
                                            ->join('sessions','carts.session_id','=','sessions.id')
                                            ->select('carts.quantity')
                                            ->where('products.sku',$sku)
                                            ->where('sessions.user_id',$user_id)
                                            ->get()->value('quantity')))

          ]);
      }
      else {
        $info=DB::table('discounts')
                ->join('products', 'discounts.id','=', 'products.discount_id')
                ->select('discounts.percentage', 'products.price')
                ->where('products.sku',$sku)
                ->get();

        $sconto=$info[0]->price*($info[0]->percentage/100);

        DB::table('sessions')
          ->where('sessions.user_id', $user_id)
          ->update(['total'=>DB::raw('total-('.
          (DB::table('products')
            ->select('price')
            ->where('sku',$sku)->get()->value('price')).'-'.$sconto.')*' .(DB::table('products')
                                            ->join('carts','carts.product_id','=','products.id')
                                            ->join('sessions','carts.session_id','=','sessions.id')
                                            ->select('carts.quantity')
                                            ->where('products.sku',$sku)
                                            ->where('sessions.user_id',$user_id)
                                            ->get()->value('quantity')))

          ]);
      }
      DB::table('carts')
        ->where('product_id',(DB::table('products')
                                ->join('carts', 'carts.product_id','=','products.id')
                                ->join('sessions', 'sessions.id','=','carts.session_id')
                                ->select('products.id')
                                ->where('products.sku',$sku)
                                ->where('sessions.user_id', $user_id)
                                ->get()
                                ->value('id')
                              )
                )
        ->delete();
    }

    public function empty_cart($email){
      $user_id=$this->email_id($email);
      DB::table('carts')
        ->where('session_id', (DB::table('sessions')
                                ->select('id')
                                ->where('user_id',$user_id)
                                ->get()
                                ->value('id'))
                )
        ->delete();

      DB::table('sessions')
          ->where('user_id',$user_id)
          ->update(['total'=>0]);

      DB::table('details')
          ->where('user_id',$user_id)
          ->where('closed',0)
          ->update(['closed'=>1]);
    }

    public function add_detail($email){
      $user_id=$this->email_id($email);
      $total= DB::table('sessions')
                  ->select('total')
                  ->where('user_id',$user_id)->get()->value('total');
      DB::table('details')->insert([
        'user_id'=> $user_id,
        'total'=>$total,
      ]);
    }

    public function add_order($prod){
      $order=DB::table('details')
              ->join('users','users.id' ,'=', 'details.user_id')
              ->join('sessions', 'users.id','=', 'sessions.user_id')
              ->join('carts','sessions.id','=','carts.session_id')
              ->join('products','products.id','=','carts.product_id')
              ->select('details.id','carts.product_id', 'carts.quantity')
              ->where('products.sku',$prod)
              ->where('details.closed',0)
              ->get();

      DB::table('orders')->insert([
        'detail_id'=>$order[0]->id,
        'product_id'=>$order[0]->product_id,
        'quantity'=>$order[0]->quantity,
      ]);

    }

    public function get_num_item_cart($email){
      $user_id=$this->email_id($email);
      $n_items=DB::table('carts')
                  ->join('sessions','carts.session_id','=','sessions.id')
                  ->select(DB::raw('count(carts.product_id) as numero'))
                  ->where('sessions.user_id',$user_id)
                  ->first();
      return response()->json($n_items);
    }
}
 ?>
