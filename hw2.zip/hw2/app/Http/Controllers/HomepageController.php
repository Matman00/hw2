<?php
namespace  App\Http\Controllers;
use Illuminate\Routing\Controller;
use App\Models\User;
use App\Http\Controllers\PagesController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;

class HomepageController extends Controller {

    public function index() {
        return view('homepage');
    }

    public function api_instagram(){
      $code = 'AQB6Z84DXdYzwEUy3jGVGK2aMIOgKbBPBcuelqJjYUvBXGhAKhvhMhl_4Loags6lFE2llmnLsxDQh5lsmtVL6W7Mv2A2Ewi9j1xINKbBeorW7jq7xiuY275UgbbnydL96A9AgAJIm7vF_jaTPK7V-W9ME6aD3841v4hqolRnP85NKklbYPqIVd9RDUAmHfjiHWi93wqxdN3_HcoVgpHYTXspizxwk885Hzpdfagi5tGmog';
      $endpoint = 'https://api.instagram.com/oauth/access_token';
      $secret_c = 'd3bbe5ccf4385bc0d7aa1a61b8042890';
      $id_c = '525413989187648';
      $redirect_url = 'https://www.racing.stewielab.it/';
      $endpoint_media = 'https://graph.instagram.com/me/';
      $access_tk;

      $dati = array("client_id" => $id_c, "client_secret" => $secret_c, "grant_type"=>"authorization_code", "redirect_uri"=> $redirect_url, "code"=>$code);
      $dati = http_build_query($dati);
      $curl = curl_init();

      curl_setopt($curl, CURLOPT_URL, $endpoint);
      curl_setopt($curl, CURLOPT_POST, 1);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $dati);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

      $result = curl_exec($curl);
      $access_tk= json_decode($result)->access_token;
      curl_close($curl);

      $curl2 = curl_init();
      curl_setopt($curl2, CURLOPT_URL,
      $endpoint_media."media?fields=media_type,media_url&access_token=".$access_tk);
      curl_setopt($curl2, CURLOPT_RETURNTRANSFER, 1);
      $json = json_decode(curl_exec($curl2))->data;
      curl_close($curl2);
      $content_array=[];
      $i=0;
      foreach($json as $content){
          $content_array[$i]['media_type']=$content->media_type;

          $content_array[$i]['media_url']=$content->media_url;


          $i++;
      }
      return response()->json($content_array);
    }

    function register(){
        $request =request();
        if($this->countErrors($request)==0){
        $password=Hash::make($request['password']);
        $newUser = DB::table('users')->insert([
          'email' => $request['email'],
          'password' => $password,
          'name' => $request['nome'],
          'surname' => $request['cognome'],
          'phone' =>$request['telefono']
          ]);

          if ($newUser) {
              Session::put('user_email', $request['email']);
              Session::put('user_name', $request['nome']);
              return redirect('homepage');
          }
          else {
              return redirect('homepage')->withInput();
          }
        }
    }

    private function countErrors($data) {
        $error = array();

        # PASSWORD
        if(!preg_match("/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%*?]{8,}$/", $data['password'])){
              $error[]="la password non soddisfa i requisiti minimi";
          }
        # CONFERMA PASSWORD
        if (strcmp($data["password"], $data["verify_password"]) != 0) {
            $error[] = "Le password non coincidono";
        }
        # EMAIL
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $error[] = "Email non valida";
        } else {
            $email = $this->get_user($data['email']);
            if (count($email) !== 0) {
                $error[] = "Email già utilizzata";
            }
        }
        #TELEFONO
        if(!preg_match('/^[0-9]{10,}$/', $data['telefono'])){
          $error[]="numero di telefono non valido";
        }else {
          $tel= $this->checkPhone($data['telefono']);
          if($tel!== null){
            $error[] = "telefono già utilizzato";
          }
        }


        return count($error);
    }

    public function checkPhone($query) {
        $res = User::where('phone', $query)->first();
        return $res;
    }

    public function get_user($query) {
        $user = User::where('email', $query)->get();
        return $user;
    }

    public function login(){
      $request =request();
      $user=$this->get_user($request['email']);
      if(count($user)!==0){
        if(Hash::check($request['password_login'] , $user[0]->password)){
          Session::put('user_email',$request['email']);
          Session::put('user_name', $user[0]->name);
          return redirect('homepage');
        }
        else{
          return redirect('homepage')->withInput($request->only('email'));
        }
      }
    }

    public function logout($email){
      $user_id=$this->get_user($email)->value('id');
      DB::table('carts')
        ->where('session_id',DB::table('sessions')
                              ->select('id')
                              ->where('user_id',$user_id)
                              ->get()
                              ->value('id')
                )
        ->delete();

        DB::table('sessions')
          ->where('user_id',$user_id)
          ->delete();

        Session::flush();
        return redirect('homepage');
    }
}
?>
