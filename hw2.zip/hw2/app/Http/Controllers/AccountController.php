<?php
namespace  App\Http\Controllers;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AccountController extends Controller {

  public function index(){
    return view("account");
  }

  private function email_id($email){
    $user=User::where('email', $email)->first();
    return $user['id'];
  }

  public function add_address($email){
    $request =request();
    if($this->countErrors($request)==0){
      $user_id=$this->email_id($email);

      $address= DB::table('addresses')->insert([
        'street'=> $request['via'],
        'postalCode'=> $request['cap'],
        'city' =>$request['citta'],
        'country' => $request['paese'],
        'phone' => $request['recapito'],
        'user_id'=>$user_id,
      ]);
      if ($address) {
          return redirect('account');
      }
      else {
          return redirect('account')->withInput();
      }
    }

  }

  public function countErrors($data){
    $error=array();

    if(!preg_match('/^[0-9]{10,}$/', $data['recapito'])){
      $error[]="numero di telefono non valido";
      echo "<h1> telefono ha caratteri</h1>";
    }
    return count($error);
  }

  public function get_address($email){
    $indirizzi = DB::table('addresses')
            ->join('users', 'addresses.user_id', '=', 'users.id')
            ->select('addresses.*')
            ->where('users.email',$email)
            ->get();
            return response()->json($indirizzi);
  }

  public function info_user($email){
    $info_user = DB::table('users')
            ->select('name', 'surname', 'email', 'phone')
            ->where('email',$email)
            ->first();
    return response()->json($info_user);
  }

  public function get_num_item_order($email){
    $user_id=$this->email_id($email);

    $n_orders=DB::table('orders')
                ->join('details','orders.detail_id','=','details.id')
                ->select(DB::raw('count(orders.detail_id) as numero'), 'details.id')
                ->where('details.user_id',$user_id)
                ->groupBy('details.id')
                ->orderByRaw('details.id DESC')
                ->get();
    return response()->json($n_orders);
  }

  public function get_orders($email){
    $user_id=$this->email_id($email);

    $orders=DB::table('products')
              ->join('orders', 'orders.product_id','=','products.id')
              ->join('details','orders.detail_id','=','details.id')
              ->select('products.pic', 'products.sku', 'details.total','details.id','details.created_at')
              ->where('details.user_id',$user_id)
              ->orderByRaw('details.created_at DESC')
              ->get();

    return response()->json($orders);
  }
}
 ?>
