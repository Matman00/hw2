<?php
namespace  App\Http\Controllers;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class ShopController extends Controller {

  public function index(){
    return view("shop");
  }

  private function email_id($email){
    $user=User::where('email', $email)->first();
    return $user['id'];
  }

  public function add_carrello($quantity,$sku,$email){
    $user_id=$this->email_id($email);
    $session=DB::table('sessions')
            ->select('id')
            ->where('user_id',$user_id)
            ->get();

    $product=DB::table('products')
            ->select('id')
            ->where('sku',$sku)
            ->get();
    DB::table('carts')->insert([
      'product_id'=>$product[0]->id,
      'session_id'=>$session[0]->id,
      'quantity'=>$quantity,
    ]);
  }

  public function add_session($email){
    $user_id=$this->email_id($email);
    $session= DB::table('sessions')->insert([
      'user_id'=>$user_id,
    ]);
  }


  public function get_session($email){
    $user_id=$this->email_id($email);
    $session = DB::table('sessions')
            ->select('*')
            ->where('user_id',$user_id)
            ->get();
    return response()->json($session);
  }


  public function get_products(){
    $products = DB::table('categories')
            ->join('products', 'categories.id', '=', 'products.category_id')
            ->join('discounts',  'discounts.id', '=', 'products.discount_id')
            ->select('discounts.active', 'discounts.percentage', 'products.name AS titolo', 'products.description', 'products.price', 'products.sku',
                    'products.quantity', 'products.pic', 'categories.name')
            ->get();
    return response()->json($products);
  }

  public function search_products($element){
    $products= DB::table('categories')
            ->join('products', 'categories.id', '=', 'products.category_id')
            ->join('discounts',  'discounts.id', '=', 'products.discount_id')
            ->select('discounts.active', 'discounts.percentage', 'products.name AS titolo', 'products.description', 'products.price', 'products.sku',
                    'products.quantity', 'products.pic', 'categories.name')
            ->where('products.name', 'like', '%'.$element.'%' )
            ->get();
    return response()->json($products);
  }


}
 ?>
