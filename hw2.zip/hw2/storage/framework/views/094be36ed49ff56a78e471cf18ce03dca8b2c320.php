<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Area Personale</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/account.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
    <script src="<?php echo e(asset('js/account.js')); ?>" defer="true"></script>
    <script src="https://kit.fontawesome.com/b0280d700f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <!---   form indirizzo    ----->
    <article class="hidden" id="modale">
      <div class="container_prev">
        <form method="POST" id="form" action="<?php echo e(url('/account/add_address/'.session('user_email'))); ?>">

          <div class="form_indirizzo">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" name="via" id="via" placeholder="Indirizzo" required>
            <input type="text" name="citta" id="citta" placeholder="Città" required>
            <input type="text" name="cap" id="cap" placeholder="CAP" required >
            <input type="text" name="paese" id="paese" placeholder="Paese" required></textarea>
            <input type="text" name="recapito" id="recapito" placeholder="Recapito" required></textarea>
            <button type="submit" id="button">Inserisci indirizzo</button>

          </div>
          <p class="" id="error"></p>
        </form>
      </div>
    </article>

    <!--- fine form indirizzo---->

    <div class="hidden" id="container_menu">
      <div id="menu_mobile">
        <a  id="account_settings1">Impostazioni Account</a>
        <a  id="ordini1">Riepilogo Ordini</a>
        <a href="<?php echo e(url('/homepage/logout/'.session('user_email'))); ?>">Logout</a>
      </div>
    </div>

  <section class="contenitore">
    <div class="zona_profilo" id="profile">

        <div class="option">
          <a  id="account_settings">Impostazioni Account</a>
          <a  id="ordini">Riepilogo Ordini</a>
          <a href="<?php echo e(url('/homepage/logout/'.session('user_email'))); ?>">Logout</a>
        </div>

    </div>
    <div class="contenuto">
      <header>
        <p class="hidden" id="cont"></p>
        <a href="<?php echo e(url('/cart')); ?>"><i class="fa fa-shopping-cart"></i></a>
        <a href="<?php echo e(url('/homepage')); ?>"><i class="fa fa-home"></i></a>
        <a href="<?php echo e(url('/shop')); ?>"><i class="fa fa-shopping-bag"></i></a>
        <div class="hidden" id="reorder">
          <a id="menu"><i class="fa fa-reorder" ></i></a>
        </div>

      </header>
      <p class='hidden' id='email_get'><?php echo e(session('user_email')); ?></p>
      <div class="box_contenuto">
        <div class="account_settings_box" id="account_settings_box">
          <div class="titolo">
            <h1>Impostazioni<br>Account</h1>
          </div>
          <h3>Account</h3>
          <div class="box">
            <div class="inner_box_account">
              <p>Nome</p>
              <p  id="nome"></p>
            </div>
            <div class="inner_box_account">
              <p>Cognome</p>
              <p id="cognome"></p>
            </div>
            <div class="inner_box_account">
              <p>Email</p>
            <p id="email"></p>
            </div>
            <div class="inner_box_account">
              <p>Telefono</p>
              <p id="telefono"></p>
            </div>
          </div>
          <h3>Indirizzi</h3>
          <div class="box" id="address">
            <div id="add_address">
              <i class="fa fa-plus-circle"></i>
            </div>
          </div>
        </div>
        <div class="hidden" id="riepilogo">
          <div class="titolo">
            <h1>Riepilogo<br>Ordini</h1>
          </div>
          </div>
        </div>
      </div>

    </div>
  </section>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\hw2\resources\views/account.blade.php ENDPATH**/ ?>