
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Shop</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/shop.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
    <script src="<?php echo e(asset('js/shop.js')); ?>" defer="true"></script>
    <script src="https://kit.fontawesome.com/b0280d700f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <header>
      <div class="navigation">
        <a href="<?php echo e(url('homepage')); ?>"> <i class="fa fa-home"></i></a>

        <?php if(session()->has('user_email')): ?>
          <p class="hidden" id="cont"></p>
          <a href='<?php echo e(url('/cart')); ?>'><i class='fa fa-shopping-cart'></i></a>
          <a href='<?php echo e(url('/account')); ?>'><i class='fa fa-user'></i></a>
        <?php endif; ?>

      </div>
      <div>
        <input type="text" id="search_bar" name="" value="">
        <button type="button"><i class="fa fa-search"></i></button>
      </div>

    </header>
    <section>
      <h1 class='hidden' id='email'><?php if(session()->has('user_email')): ?><?php echo e(session('user_email')); ?><?php endif; ?></h1>



    </section>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\hw2\resources\views/shop.blade.php ENDPATH**/ ?>