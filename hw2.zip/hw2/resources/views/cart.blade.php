<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Carrello</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/carrello.css') }}">
    <script src="{{ asset('js/carrello.js') }}" defer="true"></script>
    <script src="https://kit.fontawesome.com/b0280d700f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <header>
      <div class="navigation">
        <a href="{{ url('/homepage') }}"> <i class="fa fa-home"></i></a>
        <a href="{{ url('/account') }}"><i class="fa fa-user"></i></a>
        <a href="{{ url('/shop') }}"><i class="fa fa-shopping-bag"></i></a>
      </div>

    </header>
    <section>
        <h1 class='hidden' id='email'>@if (session()->has('user_email')){{ session('user_email') }}@endif</h1>

    </section>
  </body>
</html>
