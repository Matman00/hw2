<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>StewieLab Racing</title>
  <link rel="stylesheet" type="text/css" href="{{ asset('css/homepage.css') }}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
  <script src='{{ asset('js/login.js') }}' defer="true"></script>
  <script src='{{ asset('js/signup.js') }}' defer="true"></script>
  <script src='{{ asset('js/homepage.js') }}' defer="true"></script>
  <script src="https://kit.fontawesome.com/b0280d700f.js" crossorigin="anonymous"></script>
</head>

<body>
  @if (!session()->has('user_email'))
    <div class='login-text'>
      @else
        <div class='hidden'>
  @endif

    <button class="cta"><i class="fas fa-chevron-down fa-1x"></i></button>

    <div class="text">
      <div class="aas">
        <div>
          <a id="login">Login</a>
          <hr id="hr_login">
        </div>
        <div>
          <a id="signup">Sign Up</a>
          <hr class="hidden" id="hr_signup">
        </div>
      </div>
      <br>
      <form class="" name="login_form" id="login_form" method="post" action='{{ url('/homepage/login') }}'>
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="email" name="email" id="email_login" value='{{ old("email") }}'  placeholder="Email" >
        <br>
        <input type="password"  name="password_login"
        @if (old("email" ) !==null)
          class='error'
        @endif
        id="password_login" placeholder="Password" >
        <br>
        <button class="submit-btn" id="login_btn" name="login_btn" type="submit" disabled>Log In</button>
        @if (old("email" ) !==null)
          <p id='login_error_text' >Password errata</p>
          @else
            <p id='login_error_text' class='hidden'></p>
        @endif

      </form>

      <form class="hidden" id="signup_form" method="post" action="{{url('homepage/register')}}">
        <div class="form_signin">
          <input type="hidden" name="_token" value="{{ csrf_token() }}">
          <input type="text" name="nome" id="nome_signup"  placeholder="Nome">
          <input type="text" name="cognome" id="cognome_signup"  placeholder="Cognome">
          <input type="email" name="email" id="email_signup"  placeholder="email">
          <input type="tel" name="telefono" id="telefono_signup"  placeholder="telefono">
          <input type="password" name="password" id="password_signup" class="" placeholder="Password">
          <input type="password" name="verify_password" id="verify_password" placeholder="conferma Password">
          <button type="submit" class="submit-btn" id="signup_btn" name="button" disabled>sign in</button>
          <p id="signup_error_text" class="hiddden"></p>
        </div>

      </form>

    </div>

  </div>

  <article class="hidden" id="modale">
    <div class="container_prev">
      <form method="POST" id="form">

        <input type="hidden" name="access_key" value="28b458c6-7d67-421d-9389-3516039b4281">
        <input type="hidden" name="from_name" value="Nuovo messaggio da un cliente">
        <input type="checkbox" name="botcheck" id="checkbox">

        <!-- Custom Form Data -->
        @if (!session()->has('user_email'))
          <div class='form_input'>
          <label for='email'>E-mail</label>
          <input type='email' name='email' id='email' placeholder='mario.rossi@gmail.com' required>
        </div>
          @else

            <div class='hidden'>
            <label for='email'>E-mail</label>
            <input type='email' name='email' id='email' placeholder='mario.rossi@gmail.com' value="{{ session('user_email') }}" required>
            </div>

        @endif

        <div class="form_input">
          <label for="subject">Oggetto</label>
          <select name="subject" id="subject" required>
            <option value="Preventivo">Preventivo</option>
            <option value="Collaborazione">Collaborazione</option>
          </select>
        </div>
        <div class="form_input">
          <label for="telefono">Telefono</label>
          <input type="text" name="telefono" id="telefono" placeholder="+39 3884578587" required>
        </div>
        <div class="form_input">
          <label for="nome">Nome</label>
          <input type="text" name="nome" id="nome" placeholder="Mario" required>
        </div>
        <div class="form_input">

          <label for="cognome">Cognome</label>
          <input type="text" name="Cognome" id="cognome" placeholder="Rossi" required />
        </div>
        <div class="form_input">
          <label for="messaggio">Richiesta</label>
          <textarea name="messaggio" id="messaggio" required></textarea>
        </div>

        <div class="form_input">
          <button type="submit" id="button">Invia email</button>
        </div>
        <div id="result"></div>
      </form>
    </div>
  </article>
  <header>
    <div id="overlay"></div>
    <nav>
      <div class="logo">
        <img src="{{ asset('img/logo.png') }}" id="logo">
      </div>
      <div class="option">
        <div class="linea"></div>
        <div class="linea"></div>
        <div class="linea"></div>
      </div>

      <div id="menu">
        @if (session()->has('user_email'))
          <a href='{{ url('/homepage/logout/'.session('user_email')) }}'>Logout</a>
          <a href='{{url('account')}}'>Ciao, {{ session('user_name') }}</a>
        @endif

        <a id="collab_prev1">Collab&Prev</a>
        <a href="{{ url('shop') }}">Shop</a>
      </div>

      <div class="hidden" id="container_menu">
        <div id="menu_mobile">
          @if (session()->has('user_email'))
            <a href='{{ url('/homepage/logout/'.session('user_email')) }}'>Logout</a>
            <a href='{{url('account')}}'>Ciao, {{ session('user_name') }}</a>
          @endif
          <a href="{{ url('shop') }}">Shop</a>
          <a id="collab_prev">Collab&Prev</a>
        </div>
      </div>
    </nav>
    <h1 id="testo_header">E' la passione che ci spinge a dare il massimo</h1>
  </header>
  <section class="argomento">
    <div class="titolo_argomento">
      <h1>I nostri servizi</h1>
    </div>
    <div class="box_argomento">
      <div class="servizi">

        <img src="{{ asset("/img/img_video.jpg") }}" class="servizi_img">
        <h2>Riprese video in pista</h2><br>
        <p>Con le nostre videocamere, droni e con l'innata capacità del
          cameramen di riprendere mezzi ad alte prestazioni, siamo in grado
          di rendere uniche e indimendicabili le vostre uscite in pista.</p>

      </div>
      <div class="servizi">

        <img src="{{ asset('img/preparazioni.jpg') }}" class="servizi_img">
        <h2>Preparazioni & Lavorazioni</h2><br>
        <p>Perchè limitarsi a montare i componenti per come escono dalla
          fabbrica? Con le nostre competenze riusciamo a tirare fuori
          tutti i CV dai componenti acquistati affettuando anche lavorazioni
          meccaniche con il tornio.</p>

      </div>
      <div class="servizi">
        <img src="{{ asset('img/banco_prova.jpg') }}" class="servizi_img">
        <h2>Test su banco</h2><br>
        <p>Grazie al nuovissimo banco prova della EASYRUN diamo la possibilità
          di misurare la vera potenza del vostro scooter e di capire dove
          migliorare l'erogazione.</p>
      </div>
    </div>
  </section>

  <footer>
    <div class="footer_box">
      <h2 id="text_footer">Contatti</h2>
      <div class="footer_content">
        <i class="fa fa-phone" style='font-size:24px'></i>
        <p>3760010294</p>
      </div>

    </div>
    <div class="footer_box">


      <h2 id="text_footer">Social</h2>

      <div class="footer_content">
        <i class='fab fa-youtube' style='font-size:24px'></i>
        <a href="https://www.youtube.com/channel/UCBV9UJKn1gW-L472aLWMD5w">YouTube</a>
      </div>
      <div class="footer_content">
        <i class='fab fa-instagram' style='font-size:24px' ></i>
        <a href="https://www.instagram.com/stewielab_racing/">Instagram</a>
      </div>

    </div>
    <div class="footer_box">


      <article class="insta_box">
        <div class="testo_feed">
          <h3><a href="https://www.instagram.com/stewielab_racing/">@Stewielab racing</a></h3>
        </div>
        <div class="feed">
        </div>
      </article>
    </div>
  </footer>

</body>

</html>
