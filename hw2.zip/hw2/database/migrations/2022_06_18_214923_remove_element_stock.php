<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('create trigger remove_element_stock
        after insert on carts
        for EACH ROW
        BEGIN
        	update products
            set quantity=quantity-(SELECT quantity from carts where product_id=new.product_id)
            where id=new.product_id;
        end');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP TRIGGER `remove_element_stock`');
    }
};
