<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('detail_id');
            $table->unsignedBigInteger('product_id');
            $table->integer('quantity')->default(0);
            $table->index(['detail_id','product_id']);

            $table->index('product_id', 'idx_product');
            $table->index('detail_id', 'idx_detail');

            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('detail_id')->references('id')->on('details');

            $table->timestamp('created_at')->useCurrent()->nullable();
$table->timestamp('updated_at')->useCurrentOnUpdate()->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
};
