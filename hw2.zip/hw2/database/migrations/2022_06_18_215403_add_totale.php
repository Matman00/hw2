<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      DB::unprepared('create trigger add_totale
      after insert on carts
      for each row
      BEGIN
        IF(select s.active from discounts as s join products as p on s.id=p.discount_id  where p.id=new.product_id)=1 then
          update sessions
          set total=total+
          (
                (SELECT price from products where id=new.product_id)-
                (
                  (
                    (SELECT price from products where id=new.product_id)*
                    (select s.percentage from discounts as s join products as p on s.id=p.discount_id  where p.id=new.product_id)/
                    100
                  )
                )*(SELECT quantity from carts where product_id=new.product_id)
          )
          where id=new.session_id;

        end if;
        IF(select s.active from discounts as s join products as p on s.id=p.discount_id  where p.id=new.product_id)=0 then
          update sessions
          set total=total+
          (

              (SELECT price from products where id=new.product_id)*(SELECT quantity from carts where product_id=new.product_id)
          )
          where id=new.session_id;

        end if;
      end');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP TRIGGER `add_totale`');
    }
};
