<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomepageController@index');

Route::get('/shop', "ShopController@index");
Route::get('/shop/add_carrello/{quantita}/{sku}/{email}','ShopController@add_carrello');
Route::get('/shop/add_session/{email}','ShopController@add_session');
Route::get('/shop/get_session/{email}','ShopController@get_session');
Route::get('/shop/get_products','ShopController@get_products');
Route::get('/shop/search_products/{element}','ShopController@search_products');

Route::get('/cart', 'CartController@index');
Route::get('/cart/get_cart/{email}', 'CartController@get_cart');
Route::get('/cart/delete_item/{email}/{sku}', 'CartController@delete_item');
Route::get('/cart/empty_cart/{email}', 'CartController@empty_cart');
Route::get('/cart/add_detail/{email}', 'CartController@add_detail');
Route::get('cart/add_order/{prod}', 'CartController@add_order');
Route::get('cart/get_num_item_cart/{email}', 'CartController@get_num_item_cart');

Route::get('/homepage', 'HomepageController@index');
Route::get('/homepage/instagram', 'HomepageController@api_instagram');
Route::post('/homepage/register', "HomepageController@register");
Route::post('homepage/login', 'HomepageController@login');
Route::get('/homepage/checkEmail/{email}', "HomepageController@get_user");
Route::get('/homepage/logout/{email}', 'HomepageController@logout');


Route::get('/account', 'AccountController@index');
Route::get('/account/get_address/{email}', 'AccountController@get_address');
Route::post('/account/add_address/{email}', 'AccountController@add_address');
Route::get('/account/info_user/{email}', 'AccountController@info_user');
Route::get('account/get_num_item_order/{email}', 'AccountController@get_num_item_order');
Route::get('account/get_orders/{email}', 'AccountController@get_orders');
