let caricato=0;
let no_element=0;
function view_account_settings(event){
  const e={
    key:"Escape",
  };
  close_menu(e);
  document.getElementById("contenitore_ordini").removeAttribute("id");
  document.getElementById("testo").remove();
  no_element=0;
  const box=document.querySelector("#account_settings_box");
  box.classList.remove("hidden");
  box.classList.add("account_settings_box");
  const box_hidden=document.querySelector("#riepilogo");
  box_hidden.classList.remove("riepilogo");
  box_hidden.classList.add("hidden");
  window.scroll({
  top: 0,
  left: 0,
  behavior: 'smooth'
});
}
let n_item=[];
function save_num_item(json){

  n_item=json;
  fetch("/account/get_orders/"+email).then(onResponse).then(onJsonOrdini);

}
function view_riepilogo(event){
  const e={
    key:"Escape",
  };
  close_menu(e);
  const box=document.querySelector("#riepilogo");
  box.classList.remove("hidden");
  box.classList.add("riepilogo");
  const box_hidden=document.querySelector("#account_settings_box");
  box_hidden.classList.remove("account_settings_box");
  box_hidden.classList.add("hidden");
  window.scroll({
    top: 0,
    left: 0,
    behavior: 'smooth'
  });
  fetch("account/get_num_item_order/"+email).then(onResponse).then(save_num_item);

}

function onJsonIndirizzi(json){
  const box=document.getElementById("address");
  if(json.length>0){
      for(let j of json){
      const div=document.createElement("div");
      div.classList.add("inner_box_address");
      box.appendChild(div);

      let p=document.createElement("p");
      p.textContent=j.street;
      div.appendChild(p);

      p=document.createElement("p");
      p.textContent=j.city+", "+j.postalCode+", "+j.country;
      div.appendChild(p);

      p=document.createElement("p");
      p.textContent=j.phone;
      div.appendChild(p);
    }
  }
}
function onJsonOrdini(json){
  if(no_element){
    document.getElementById("contenitore_ordini").removeAttribute("id");
    document.getElementById("testo").remove();
  }
if(caricato){
  const verifica=document.querySelectorAll(".box_ordini");
  for(let v of verifica){
    v.remove();
  }
}

  const riepilogo=document.getElementById("riepilogo");
  if(json.length>0){
    for(let n of n_item){

      for(let i=0;i<json.length;i++){

        let check=1;
        let indice=i;

        if(n.id===json[i].id){
          const box_ordini=document.createElement("div");
          box_ordini.classList.add("box_ordini");
          riepilogo.appendChild(box_ordini);
          caricato=1;
          if(check){
            const frist=document.createElement("div");
            frist.classList.add("frist");
            box_ordini.appendChild(frist);

            let img=document.createElement("img");
            img.src=json[i].pic;
            frist.appendChild(img);

            check=0;
            i=i+n.numero; //prima immagine del ordine successivo

          }
          const info_box=document.createElement("div");
          info_box.classList.add("info_ordini_box");
          box_ordini.appendChild(info_box);

          const box_info_scrittura=document.createElement("div");
          box_info_scrittura.classList.add("box_info_scrittura");
          info_box.appendChild(box_info_scrittura);
          //nuemro ordine
          let div=document.createElement("div");
          box_info_scrittura.appendChild(div);

          let p=document.createElement("p");
          p.textContent="Numero Ordine";
          div.appendChild(p);

          let h2=document.createElement("h2");
          h2.textContent=n.id;
          div.appendChild(h2);

          //totale
          div=document.createElement("div");
          box_info_scrittura.appendChild(div);

          p=document.createElement("p");
          p.textContent="Totale";
          div.appendChild(p);

          h2=document.createElement("h2");
          h2.textContent=json[indice].total;
          div.appendChild(h2);
          if(n.numero>1){

            const more_orders=document.createElement("div");
            more_orders.classList.add("more_orders");
            info_box.appendChild(more_orders);

            p=document.createElement("p");
            p.textContent="Altri Prodotti...";
            more_orders.appendChild(p);

            const imgs=document.createElement("div");
            imgs.classList.add("imgs");
            more_orders.appendChild(imgs);
            let prodotto=0;
            for(let a=indice+1;a<json.length;a++){

              if(prodotto!==n.numero-1 && prodotto<1){
                let img=document.createElement("img");
                img.src=json[a].pic;
                imgs.appendChild(img);
                prodotto++;
              }
              if(n.numero>2 && prodotto===1){
                let img=document.createElement("img");
                img.src="../img/altro.png";
                imgs.appendChild(img);
                a=json.length;
              }
            }
          }
        }
      }
    }
  }
  else{
    const contenuto= document.querySelector(".contenuto");
    contenuto.id="contenitore_ordini";
    const testo=document.createElement("h3");
    testo.textContent="Nessun ordine da visualizzare..";
    testo.id="testo";
    contenuto.appendChild(testo);
    no_element=1;
  }
}

function onJsonEmail(json){
  document.getElementById("nome").textContent=json.name;
  document.getElementById("cognome").textContent=json.surname;
  document.getElementById("telefono").textContent=json.phone;
  document.getElementById("email").textContent=json.email;
}

function viewNumItem(json){
  if(json.numero>0){
    const cont=document.getElementById('cont');
    cont.classList.remove("hidden");
    cont.textContent=json.numero;
  }
}

function onResponse(response) {
  return response.json();
}
function off_modale(event) {

  const key = event.key;
  if (key === "Escape") {
    const article = document.querySelector("#modale");
    article.classList.remove("modale");
    article.classList.add("hidden");
    document.body.classList.remove("no-scroll");
  }
}

function modale() {
  const article = document.querySelector("#modale");
  article.classList.remove("hidden");
  article.classList.add("modale");
  document.body.classList.add("no-scroll");
  window.addEventListener('keydown', off_modale);

}

function close_menu(event) {
  const key = event.key;
  if (key === "Escape") {
    const container_menu = document.querySelector("#container_menu");
    container_menu.classList.remove("modale");
    container_menu.classList.add("hidden");
    off_modale(event);
  }
}
function open_menu() {
  const container_menu = document.querySelector("#container_menu");
  container_menu.classList.remove("hidden");
  container_menu.classList.add("modale");
  document.body.classList.add("no-scroll");
  window.addEventListener('keydown', close_menu);
  const riepilogo_ordini=document.querySelector("#ordini1");
  riepilogo_ordini.addEventListener('click', view_riepilogo);
  const account_settings=document.querySelector("#account_settings1");
  account_settings.addEventListener('click',view_account_settings);

}


const menu=document.getElementById("menu");
menu.addEventListener('click', open_menu);

  const add_address = document.querySelector("#add_address");
  add_address.addEventListener('click', modale);

const account_settings=document.querySelector("#account_settings");
account_settings.addEventListener('click',view_account_settings);
const riepilogo_ordini=document.querySelector("#ordini");
riepilogo_ordini.addEventListener('click', view_riepilogo);


const email=document.getElementById("email_get").textContent;
fetch('cart/get_num_item_cart/'+email).then(onResponse).then(viewNumItem);
fetch('account/get_address/'+email).then(onResponse).then(onJsonIndirizzi);
fetch('account/info_user/'+email).then(onResponse).then(onJsonEmail);
